---
name: Precision Nordic Luster
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf6'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e8edff'
  surface-container-high: '#e0e8ff'
  surface-container-highest: '#d7e2ff'
  on-surface: '#101b30'
  on-surface-variant: '#44474c'
  inverse-surface: '#263046'
  inverse-on-surface: '#edf0ff'
  outline: '#74777d'
  outline-variant: '#c4c6cc'
  surface-tint: '#525f71'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0f1c2c'
  on-primary-container: '#778598'
  inverse-primary: '#bac8dc'
  secondary: '#bb0112'
  on-secondary: '#ffffff'
  secondary-container: '#e02928'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a1700'
  on-tertiary-container: '#b87500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e4f9'
  primary-fixed-dim: '#bac8dc'
  on-primary-fixed: '#0f1c2c'
  on-primary-fixed-variant: '#3a4859'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000b'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9ff'
  on-background: '#101b30'
  surface-variant: '#d7e2ff'
typography:
  headline-xl:
    fontFamily: Barlow Condensed
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: 0.02em
  headline-xl-mobile:
    fontFamily: Barlow Condensed
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: 0.01em
  headline-lg:
    fontFamily: Barlow Condensed
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Barlow Condensed
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0.01em
  headline-md:
    fontFamily: Barlow Condensed
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: Barlow Condensed
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 2rem
  margin-lg: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses high-end automotive craftsmanship, reliability, and precision utility tailored for premier mobile detailing services. The aesthetic fuses **Tactile / Skeuomorphic-lite precision** with **High-Contrast Modern Utility**: surfaces recall hand-buffed clear coats, surgical detailing lights, and mechanical solidness without clutter.

### Target Audience & Emotional Intent
- **Audience:** Discerning vehicle owners, daily commuters, and luxury car enthusiasts in the Greater Toronto Area seeking hassle-free, concierge-level care at their home or workplace.
- **Emotional Impact:** Absolute confidence, clinical cleanliness, effortless scheduling, and national pride centered on uncompromising service standards.

### Aesthetic Principles
- **Concierge Rigor:** Sharp, organized layouts with definitive structural boundaries that communicate meticulous care.
- **Specular Contrast:** Deep nocturnal navies balanced with gleaming pure whites and vibrant maple accents to reflect the transition from road grime to showroom finish.
- **Conversion Immediacy:** Clear, high-impact calls to action with tactile visual feedback optimized for high-urgency mobile bookings.

## Colors

The palette balances authoritative deep automotive navies with vivid Canadian crimson accents and reflective neutrals to guarantee AAA contrast and decisive conversion pathways.

### Palette Architecture
- **Primary Navy (`#0D1B2A`):** The foundational anchor. Deployed for dominant structural bars, high-contrast dark sections, hero backdrops, and heavy display titles.
- **Secondary Crimson (`#DC2626`):** The primary conversion driver. Reserved exclusively for direct action triggers (Book Now, Call Now), active vehicle size toggles, and urgent appointment callouts.
- **Tertiary Amber (`#F59E0B`):** Trust and prestige accent. Used for customer review star ratings, verified guarantee seals, and limited-slot badges.
- **Neutral Navy-Slate (`#1B263B`):** Secondary container surface, supporting text on dark variants, and subtle card borders.

### Surface System
- **Canvas Base (`#F8F9FA`):** Crisp, glare-free background maintaining visual cleanliness and high legibility.
- **Surface Clean (`#FFFFFF`):** High-gloss content cards, input fields, and pricing tables.
- **Surface Muted (`#F1F5F9`):** Package comparison tracks, vehicle silhouette selectors, and subtle segmented control wells.
- **Metallic Silver Accent (`#E2E8F0`):** Polished chrome dividers, hairline card perimeters, and inactive badge strokes.

## Typography

The typographic hierarchy combines the muscular, mechanical presence of **Barlow Condensed** with the ultra-legible, human-centric geometry of **Plus Jakarta Sans**.

### Usage Guidelines
- **Barlow Condensed:** Used for all section headers, package tiers, price tags, and hero copy. Its condensed profile mimics precision gauges, tachometers, and automotive emblems, allowing powerful statements within tight horizontal mobile spaces. Use uppercase styling for tags, short labels, and section badges.
- **Plus Jakarta Sans:** Governs all long-form copy, booking forms, vehicle spec breakdowns, and technical service inclusions. Provides exceptional clarity on mobile screens under direct sunlight.

## Layout & Spacing

A mobile-first fluid layout configured to support high-velocity booking actions and transparent package comparisons.

### Grid & Breakpoints
- **Mobile (< 768px):** 4-column layout with `1rem` margins and `1rem` gutters. Touch targets adhere strictly to a 48px baseline (minimum 44px). Sticky bottom viewport navigation permanently allocates 64px of clearance.
- **Tablet (768px - 1024px):** 8-column layout with `2rem` margins and `1.5rem` gutters. Service packages shift into 2-up grids; vehicle size selectors expand horizontally.
- **Desktop (> 1024px):** 12-column layout capped at `1280px` max-width with `4rem` margins and `2rem` gutters. Service tiers display 3-up side-by-side with sticky summary booking sidebars.

## Elevation & Depth

Visual hierarchy uses a hybrid of clean automotive gloss and structural depth, reflecting the transition from raw surface to multi-stage ceramic coating.

### Depth System
- **Level 0 (Flat Ground):** Base page background (`#F8F9FA` or dark navy `#0D1B2A`) with no cast shadow.
- **Level 1 (Card & Module Layer):** Clean surface (`#FFFFFF`) with a 1px perimeter line of `#E2E8F0` and subtle ambient ground: `0 2px 8px -2px rgba(13, 27, 42, 0.06), 0 1px 3px 0 rgba(13, 27, 42, 0.04)`.
- **Level 2 (Hover & Elevated Elements):** Interactive packages on focus: `0 12px 24px -4px rgba(13, 27, 42, 0.10), 0 4px 8px -2px rgba(13, 27, 42, 0.04)`.
- **Level 3 (Sticky Booking Bar & Floating Overlays):** Bottom mobile booking bar and sticky quick-call buttons: `0 -4px 20px rgba(13, 27, 42, 0.12)`.
- **Gloss Sheen Detail:** Primary Red action buttons feature a 1px interior highlight stroke (`rgba(255, 255, 255, 0.25) inset top`) creating a polished, tactile glass-coat feel.

## Shapes

The interface implements **Rounded (0.5rem base)** corner radii. This geometry captures the aerodynamic flow lines of modern performance vehicles—softer than industrial machinery, yet far firmer and more athletic than consumer pill-based apps.

### Corner Treatment
- **Buttons, Text Inputs, and Dropdowns:** `0.5rem` (8px). Maintains structural authority and distinct boundary definitions for rapid finger targeting.
- **Package Cards, Modals, and Media Blocks:** `1rem` (16px) via `rounded-lg`. Softens large content sections while maintaining a structured architectural frame.
- **Trust Badges & Micro Pills:** `9999px` (Full pill). Used exclusively for review counters, rating stars, and vehicle category pills (Sedan, SUV, Truck).

## Components

### Buttons
- **Primary CTA ("Book Detail"):** Solid `#DC2626` background, white text (`label-lg`), subtle gloss top-border inset (`rgba(255,255,255,0.2)`), 0.5rem radius, min-height 48px. Pressed state lowers brightness by 10% with a 1px downward translation.
- **Secondary CTA ("Instant Quote"):** `#0D1B2A` background, white text, 0.5rem radius, paired alongside primary for high-contrast duality.
- **Tertiary / Outlined ("View Packages"):** 1.5px solid `#0D1B2A`, transparent background, dark navy text. Hover brings `#F1F5F9` background fill.

### Input Fields & Selectors
- **Form Controls:** 48px height, 1px solid `#E2E8F0` border, `#FFFFFF` background, `0.5rem` radius. Label positioned above in `label-sm` with dark navy tone. Focused state applies a 2px ring in `#0D1B2A` with zero layout shift.
- **Vehicle Type Selectors:** Segmented multi-select cards featuring vehicle vector icons (Coupe, Sedan, SUV, Truck). Selected state: 2px solid `#DC2626` border, subtle red tint (`#FEF2F2`), and an active check indicator.

### Trust Badges & Social Proof
- **Review Strip:** Surface `#FFFFFF` pill with `#E2E8F0` border. Houses five `#F59E0B` solid stars, numeric score "4.9/5", and Maple leaf badge motif ("Brampton's Top Rated Mobile Spa").
- **Guarantee Badge:** Navy pill container, white micro text, accompanied by a stylized red maple leaf and gold verification shield icon.

### Cards & Service Packages
- **Package Card:** Surface `#FFFFFF`, 1px solid `#E2E8F0`, 16px padding mobile / 24px desktop. Includes pricing tier in `Barlow Condensed` (`headline-lg`), bulleted checklists with green/red check indicators, estimated service duration tag, and full-width bottom CTA.
- **Popular Package Highlight:** Framed with a 2px `#DC2626` border and an anchored top ribbon: "MOST POPULAR - BRAMPTON & PEEL".

### Checkboxes & Radios
- **Controls:** 20px x 20px box, 4px corner radius for checkboxes, full circle for radios. Unchecked: 1.5px border `#94A3B8`. Checked: solid `#DC2626` with crisp white SVG checkmark.

### Sticky Conversion Tray
- **Mobile Floating Bar:** Docked fixed to viewport bottom (`z-index: 100`). White backdrop with frosted blur (`backdrop-filter: blur(12px)`), top border `1px solid #E2E8F0`, padding `0.75rem 1rem`. Contains immediate Call Button (`#0D1B2A`, telephone icon) and Book Now button (`#DC2626`, calendar icon) in a 40/60 split.